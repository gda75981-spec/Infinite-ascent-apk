Infinite Ascent — Android WebView wrapper project

This project packages your existing index.html into a fullscreen Android app.
It is a project ZIP, not a precompiled APK. GitHub Actions can compile the APK.

Build using GitHub (tablet-friendly):
1. Create a GitHub repository and upload every file/folder in this ZIP.
2. Open the repository's Actions tab.
3. Select "Build Android APK" and press "Run workflow" (or push to main).
4. Open the completed workflow run, scroll to Artifacts, and download
   Infinite-Ascent-debug-apk.
5. Extract the artifact ZIP and install app-debug.apk on your Android tablet.
   If Android blocks it, allow installing unknown apps for the app you used
   to download/open the APK.

Notes:
- The game's Three.js library and Google Fonts are loaded from the internet by
  the original HTML, so those features need an internet connection unless the
  HTML is changed to bundle those libraries locally.
- This is a debug APK for personal testing, not a Play Store release.
